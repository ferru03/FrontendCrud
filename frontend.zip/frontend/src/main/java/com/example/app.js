const people = [
    {
        id: 10001,
        birthDate: "1953-09-01",
        firstName: "Georgi",
        lastName: "Facello",
        gender: "M",
        hireDate: "1986-06-25",
    },
    {
        id: 10002,
        birthDate: "1964-06-01",
        firstName: "Bezalel",
        lastName: "Simmel",
        gender: "F",
        hireDate: "1985-11-20",
    },
    {
        id: 10003,
        birthDate: "1959-12-02",
        firstName: "Parto",
        lastName: "Bamford",
        gender: "M",
        hireDate: "1986-08-27T22:00:00.000+0000",
    },
    {
        id: 10004,
        birthDate: "1954-04-30",
        firstName: "Chirstian",
        lastName: "Koblick",
        gender: "M",
        hireDate: "1986-11-30",
    },
    {
        id: 10005,
        birthDate: "1955-01-20",
        firstName: "Kyoichi",
        lastName: "Maliniak",
        gender: "M",
        hireDate: "1989-09-11T22:00:00.000+0000",
    }
]

const mainDiv = document.querySelector("main")

const idInput = document.querySelector('input[name="id"]');
const nameInput = document.querySelector('input[name="firstName"]')
const lastNameInput = document.querySelector('input[name="lastName"]')
const createButton = document.querySelector("button#createitem")

const updateId = document.querySelector('input[name="updateId"]');
const updateName = document.querySelector('input[name="updateName"]')
const updateLastName = document.querySelector('input[name="updateLastName"]')
const updateFormButton = document.querySelector("button#updateitem")

const renderData = () => {
mainDiv.innerHTML = ""

people.forEach((person, index) => {
    const personH1 = document.createElement("h1")
    const buttonContainer = document.createElement("aside")

    const deleteButton = document.createElement(`button`)
    deleteButton.id = index
    deleteButton.innerText = "Elimina"
    deleteButton.addEventListener("click", event => {
    people.splice(index, 1)
    renderData()
    })
    buttonContainer.appendChild(deleteButton)

    const updateButton = document.createElement(`button`)
    updateButton.id = index
    updateButton.innerText = "Modifica"
    updateButton.addEventListener("click", event => {
    updateId.value = person.id
    updateName.value = person.firstName
    updateLastName.value = person.lastName
    updateFormButton.setAttribute("toupdate", index)
    })
    buttonContainer.appendChild(updateButton)
    personH1.innerText = `Id: ${person.id}, Nome: ${person.firstName}, Cognome: ${person.lastName}`
    mainDiv.appendChild(personH1)
    mainDiv.appendChild(buttonContainer)
})
}

const createData = () => {
const firstName = nameInput.value
const id = idInput.value
const lastName = lastNameInput.value
const newPerson = { firstName, id, lastName}
people.push(newPerson)
renderData()
}

const updateData = event => {
const index = event.target.getAttribute("toupdate")
const firstName = updateName.value
const id = updateId.value
const lastName = updateLastName.value
people[index] = { firstName, id, lastName}
renderData()
}

createButton.addEventListener("click", createData)
updateFormButton.addEventListener("click", updateData)
